module.exports = {
    dependencies: {
        "com.prodz.tiflexigrid": "1.2",
        "it.dmi.unict": "1.0",
        "cast.info": "1.0",
        "season.info": "1.0",
        "favourite.info": "1.0"
    }
};