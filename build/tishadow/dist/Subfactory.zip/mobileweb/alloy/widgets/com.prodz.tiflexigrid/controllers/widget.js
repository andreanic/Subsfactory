function WPATH(s) {
    var index = s.lastIndexOf("/");
    var path = -1 === index ? "com.prodz.tiflexigrid/" + s : s.substring(0, index) + "/com.prodz.tiflexigrid/" + s.substring(index + 1);
    return path;
}

function __processArg(obj, key) {
    var arg = null;
    if (obj) {
        arg = obj[key] || null;
        delete obj[key];
    }
    return arg;
}

function Controller() {
    new (__p.require("alloy/widget"))("com.prodz.tiflexigrid");
    this.__widgetId = "com.prodz.tiflexigrid";
    __p.require("alloy/controllers/BaseController").apply(this, Array.prototype.slice.call(arguments));
    this.__controllerPath = "widget";
    this.args = arguments[0] || {};
    if (arguments[0]) {
        __processArg(arguments[0], "__parentSymbol");
        __processArg(arguments[0], "$model");
        __processArg(arguments[0], "__itemTemplate");
    }
    var $ = this;
    var exports = {};
    $.__views.fgMain = Ti.UI.createView({
        backgroundColor: "#fff",
        id: "fgMain"
    });
    $.__views.fgMain && $.addTopLevelView($.__views.fgMain);
    $.__views.fgWrapper = Ti.UI.createView({
        width: Ti.UI.FILL,
        height: Ti.UI.FILL,
        backgroundColor: "transparent",
        id: "fgWrapper"
    });
    $.__views.fgMain.add($.__views.fgWrapper);
    $.__views.fgScrollView = Ti.UI.createScrollView({
        width: Ti.UI.FILL,
        height: Ti.UI.FILL,
        contentHeight: Ti.UI.SIZE,
        contentWidth: Ti.UI.FILL,
        layout: "horizontal",
        backgroundColor: "transparent",
        scrollType: "vertical",
        id: "fgScrollView"
    });
    $.__views.fgWrapper.add($.__views.fgScrollView);
    exports.destroy = function() {};
    _.extend($, $.__views);
    var params, columns, space, data, screenWidth, newWidth, columnWidth, frameBGcolor, itemsOptions, onItemClick;
    var init = function(opts) {
        params = opts || {};
        columns = params.columns || 4;
        space = params.space || 5;
        data = params.data || {};
        screenWidth = params.width || Ti.Platform.displayCaps.getPlatformWidth();
        newWidth = screenWidth - space;
        columnWidth = newWidth / columns - space;
        $.fgScrollView.left = space;
        $.fgScrollView.top = 0;
        $.fgScrollView.right = -1;
        frameBGcolor = params.gridBackgroundColor || "#fff";
        $.fgMain.backgroundColor = frameBGcolor;
        itemsOptions = {
            heightDelta: params.itemHeightDelta || 0,
            backgroundColor: params.itemBackgroundColor || "transparent",
            borderWidth: params.itemBorderWidth || 0,
            borderColor: params.itemBorderColor || "transparent",
            borderRadius: params.itemBorderRadius || 0
        };
        onItemClick = params.onItemClick || function() {
            __log.info("TiFlexiGrid -> onItemClick is not defined.");
        };
        __log.info("TiFlexiGrid -> Widget initialized.");
        __log.info("TiFlexiGrid -> Items dimension: " + columnWidth + " x " + (columnWidth + itemsOptions.heightDelta));
        addGridItems(data);
    };
    var addGridItems = function(args) {
        clearGrid();
        data = args || {};
        for (var x = 0; x < data.length; x++) addGridItem(data[x]);
    };
    var addGridItem = function(item) {
        var frame = Ti.UI.createView({
            width: columnWidth,
            height: columnWidth + itemsOptions.heightDelta,
            backgroundColor: itemsOptions.backgroundColor,
            top: 0,
            left: 0,
            right: space,
            bottom: space,
            borderColor: itemsOptions.borderColor,
            borderRadius: itemsOptions.borderRadius,
            borderWidth: itemsOptions.borderWidth
        });
        var overlay = Ti.UI.createImageView({
            top: 0,
            width: Ti.UI.FILL,
            height: "60%",
            backgroundColor: params.itemBackgroundColor,
            image: __p.file(item.data.image),
            zIndex: 1,
            data: item.data
        });
        item.view;
        var itemTitle = Ti.UI.createLabel({
            color: "white",
            backgroundColor: params.itemBackgroundColor,
            font: {
                fontSize: 20
            },
            text: item.data.title,
            textAlign: Ti.UI.TEXT_ALIGNMENT_CENTER,
            top: "60%",
            bottom: 0,
            width: Ti.UI.FILL,
            height: Ti.UI.FILL
        });
        overlay.addEventListener("click", function(e) {
            onItemClick(e);
        });
        frame.add(overlay);
        frame.add(itemTitle);
        $.fgScrollView.add(frame);
    };
    var clearGrid = function() {
        $.fgScrollView.removeAllChildren();
    };
    var getItemWidth = function() {
        return columnWidth;
    };
    var getItemHeight = function() {
        return columnWidth + itemsOptions.heightDelta;
    };
    var setOnItemClick = function(fnt) {
        onItemClick = fnt || function() {
            __log.info("TiFlexiGrid -> onItemClick is not defined.");
        };
    };
    exports.init = init;
    exports.addGridItems = addGridItems;
    exports.clearGrid = clearGrid;
    exports.addGridItem = addGridItem;
    exports.getItemWidth = getItemWidth;
    exports.getItemHeight = getItemHeight;
    exports.setOnItemClick = setOnItemClick;
    _.extend($, exports);
}

var Alloy = __p.require("alloy"), Backbone = Alloy.Backbone, _ = Alloy._;

module.exports = Controller;